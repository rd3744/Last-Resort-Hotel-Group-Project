-- How do individual guests compare to corporate organizations in advance booking time for sleeping rooms?
SELECT Customer.CustomerType, 
COUNT (Reservation.reservationID) AS totalBookings,
ROUND(AVG(julianday(ReservationPreferenceSleeping.checkInDate) - julianday(Reservation.dateResMade))) AS avgDaysInAdvance
FROM Reservation
JOIN Customer ON Reservation.customerID = Customer.customerID
JOIN ReservationPreference ON Reservation.reservationID = ReservationPreference.reservationID
JOIN ReservationPreferenceSleeping ON ReservationPreference.reservationPreferenceID = ReservationPreferenceSleeping.preferenceSID
GROUP BY Customer.customerType
ORDER BY avgDaysInAdvance DESC;
-- How often do assigned rooms actually match a guest's requested proximity preferences (i.e. Garage and Pool)?
SELECT ReservationPreferenceSleeping.proximityPref, Wings.nearPool, Wings.nearGarage,
COUNT (RoomAssignment.assignmentID) AS assignedRoomCount
FROM ReservationPreferenceSleeping
JOIN RoomAssignment ON ReservationPreferenceSleeping.preferenceSID = RoomAssignment.reservationPreferenceID
JOIN RoomDetail ON RoomAssignment.roomID = RoomDetail.roomID
JOIN Wings ON RoomDetail.wingID = Wings.wingID
WHERE ReservationPreferenceSleeping.proximityPref IS NOT NULL
GROUP BY ReservationPreferenceSleeping.proximityPref, Wings.nearPool, Wings.nearGarage
ORDER BY ReservationPreferenceSleeping.proximityPref, assignedRoomCount DESC;
-- Who are repeat guests and how many nights have they stayed?
SELECT Guest.guestID, Guest.guestFirstName, Guest.guestLastName,
COUNT(Stay.stayID) AS totalStays,
ROUND(SUM(julianday(Stay.actualCheckOut) - julianday(Stay.actualCheckIn)), 1) AS totalNightsStayed
FROM guest 
JOIN Stay ON Guest.guestID = Stay.guestID
GROUP BY Guest.guestID, Guest.guestFirstName, Guest.guestLastName
HAVING COUNT(Stay.stayID) > 1
ORDER BY totalStays DESC, totalNightsStayed DESC;

#Eric's queries:
#1. How much of each building's sleeping-room inventory was occupied during September through November?
SELECT Hotel.hotelName, Building.buildingName, COUNT(Stay.stayID) AS completedStays
FROM Hotel
JOIN Building ON Hotel.hotelID=Building.hotelID
JOIN Wings ON Building.buildingID=Wings.buildingID
JOIN Room ON Wings.wingID=Room.wingID
JOIN RoomAssignment ON Room.roomID=RoomAssignment.roomID
JOIN Stay ON RoomAssignment.assignmentID=Stay.assignmentID
WHERE Stay.actualCheckOut IS NOT NULL
GROUP BY Hotel.hotelID, Building.buildingID
ORDER BY completedStays DESC;

#2. Which properties could accommodate a party of four in one room with two queen beds for November 11–15, 2026?
SELECT Hotel.hotelName, COUNT(*) AS qualifyingRooms, MIN(Room.baseRate) AS lowestRate
FROM Hotel
JOIN Building ON Hotel.hotelID=Building.hotelID
JOIN Wings ON Building.buildingID=Wings.buildingID
JOIN Room ON Wings.wingID=Room.wingID
JOIN roomBed ON Room.roomID=roomBed.roomID
WHERE Room.roomStatus='Available' AND Room.sleepingCapacity >= 4
  AND roomBed.bedSize='Queen' AND roomBed.bedQuantity >= 2
GROUP BY Hotel.hotelID
ORDER BY lowestRate;

#3. Which confirmed event time slots have too few seats if all estimated attendees participate? Combine rooms reserved for the same event and slot.
SELECT Event.EventName, EventRoomBooking.BookingDate, MeetingTimeSlot.SlotName,
       Room.roomNumber, Event.EstimatedAttendance, Room.meetingCapacity,
       Event.EstimatedAttendance-Room.meetingCapacity AS seatShortfall
FROM EventRoomBooking
JOIN Event ON EventRoomBooking.EventID=Event.EventID
JOIN Room ON EventRoomBooking.RoomID=Room.roomID
JOIN MeetingTimeSlot ON EventRoomBooking.TimeSlotID = MeetingTimeSlot.TimeSlotID
WHERE EventRoomBooking.BookingStatus='Confirmed'
  AND Room.meetingCapacity < Event.EstimatedAttendance
ORDER BY seatShortfall DESC;

#Roopak
#Query 1: Total revenue for each service category
SELECT Service.category, COUNT(Charge.chargeID) AS numCharges, SUM(Charge.quantity * Charge.unitPrice) AS revenue
FROM Charge
JOIN Service ON Charge.serviceID = Service.serviceID
GROUP BY Service.category
ORDER BY revenue DESC;

#Query 2: Amount still owed on unpaid invoices, by billing account
SELECT BillingAccount.accountID, BillingAccount.accountType, guest.guestFirstName, guest.guestLastName, SUM(Charge.quantity * Charge.unitPrice * ChargeAllocation.splitPercent / 100) AS amountOwed
FROM ChargeAllocation
JOIN Invoice ON ChargeAllocation.invoiceID=Invoice.invoiceID
JOIN Charge ON ChargeAllocation.chargeID=Charge.chargeID
JOIN BillingAccount ON ChargeAllocation.accountID=BillingAccount.accountID
JOIN guest ON BillingAccount.guestID=guest.guestID
WHERE Invoice.status!='Paid'
GROUP BY BillingAccount.accountID
ORDER BY amountOwed DESC;

#Query 3: How much each type of account pays for each service category
SELECT Service.category, BillingAccount.accountType, SUM(Charge.quantity * Charge.unitPrice * ChargeAllocation.splitPercent / 100) AS amountPaid
FROM ChargeAllocation
JOIN Charge ON ChargeAllocation.chargeID = Charge.chargeID
JOIN Service ON Charge.serviceID = Service.serviceID
JOIN BillingAccount ON ChargeAllocation.accountID = BillingAccount.accountID
GROUP BY Service.category, BillingAccount.accountType
ORDER BY Service.category, amountPaid DESC;

#Saani -- webpage
#Events Query 1: How many guests are recorded as registered, checked in, or cancelled for each event?
SELECT Event.EventName, EventAttendance.AttendanceStatus, COUNT(*) AS guestCount
FROM EventAttendance
JOIN Event ON EventAttendance.EventID = Event.EventID
GROUP BY Event.EventID, EventAttendance.AttendanceStatus
ORDER BY Event.StartDateTime, EventAttendance.AttendanceStatus;

#Event Query 2: Which time slots have the most confirmed event room bookings?
SELECT MeetingTimeSlot.SlotName, COUNT(*) AS confirmedRoomBookings
FROM EventRoomBooking
JOIN MeetingTimeSlot ON EventRoomBooking.TimeSlotID = MeetingTimeSlot.TimeSlotID
WHERE EventRoomBooking.BookingStatus='Confirmed'
GROUP BY MeetingTimeSlot.TimeSlotID
ORDER BY confirmedRoomBookings DESC, MeetingTimeSlot.StartTime;

#Event Query 3:Which event types bring the most overnight guests to the resort?
SELECT Event.EventType, COUNT(*) AS eventCount, SUM(Event.EstimatedHotelGuests) AS expectedHotelGuests
FROM Event
GROUP BY Event.EventType
ORDER BY expectedHotelGuests DESC, Event.EventType;
