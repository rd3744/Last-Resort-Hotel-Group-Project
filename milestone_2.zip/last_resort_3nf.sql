-- Last Resort. Run once in a new SQLite database.
-- The four team sections use the same IDs as the original dataset.
PRAGMA foreign_keys = ON;
BEGIN TRANSACTION;

-- Eric: Hotel Structure and Rooms

CREATE TABLE Hotel (
    hotelID INTEGER PRIMARY KEY,
    hotelName TEXT NOT NULL
);

CREATE TABLE Building (
    buildingID INTEGER PRIMARY KEY,
    buildingName TEXT NOT NULL,
    hotelID INTEGER NOT NULL,
    FOREIGN KEY (hotelID) REFERENCES Hotel(hotelID)
);

CREATE TABLE Wings (
    wingID INTEGER PRIMARY KEY,
    wingName TEXT NOT NULL,
    buildingID INTEGER NOT NULL,
    nearPool BOOLEAN NOT NULL,
    nearGarage BOOLEAN NOT NULL,
    handicapAccess BOOLEAN NOT NULL,
    UNIQUE (buildingID, wingName),
    FOREIGN KEY (buildingID) REFERENCES Building(buildingID)
);

-- A room category specifies its bed installation (permanent, foldaway, or none).
-- Bed sizes and quantities remain individual room inventory.
CREATE TABLE RoomCategory (
    roomType TEXT NOT NULL PRIMARY KEY,
    bedType TEXT NOT NULL
);

CREATE TABLE RoomDetail (
    roomID INTEGER PRIMARY KEY,
    wingID INTEGER NOT NULL,
    roomNumber TEXT NOT NULL,
    roomType TEXT NOT NULL,
    hasToilet BOOLEAN NOT NULL,
    hasBath BOOLEAN NOT NULL,
    sleepingCapacity INTEGER NOT NULL,
    meetingCapacity INTEGER NOT NULL,
    largeExtraSpace BOOLEAN NOT NULL,
    smokingStatus TEXT NOT NULL,
    baseRate FLOAT NOT NULL,
    roomStatus TEXT NOT NULL,
    UNIQUE (wingID, roomNumber),
    FOREIGN KEY (roomType) REFERENCES RoomCategory(roomType),
    FOREIGN KEY (wingID) REFERENCES Wings(wingID)
);

CREATE TABLE roomBed (
    roomID INTEGER NOT NULL,
    bedSize TEXT NOT NULL,
    bedQuantity INTEGER NOT NULL,
    PRIMARY KEY (roomID, bedSize),
    FOREIGN KEY (roomID) REFERENCES RoomDetail(roomID)
);

CREATE TABLE roomAdjacency (
    roomID1 INTEGER NOT NULL,
    roomID2 INTEGER NOT NULL,
    isMovableWall BOOLEAN NOT NULL,
    CHECK (roomID1 < roomID2),
    PRIMARY KEY (roomID1, roomID2),
    FOREIGN KEY (roomID1) REFERENCES RoomDetail(roomID),
    FOREIGN KEY (roomID2) REFERENCES RoomDetail(roomID)
);

-- Ava: Guests and Reservations

CREATE TABLE customer (
    customerID INTEGER PRIMARY KEY,
    customerType TEXT NOT NULL
);

CREATE TABLE guest (
    guestID INTEGER PRIMARY KEY,
    guestFirstName TEXT NOT NULL,
    guestLastName TEXT NOT NULL,
    guestPhone TEXT NOT NULL,
    guestEmail TEXT NOT NULL UNIQUE,
    FOREIGN KEY (guestID) REFERENCES customer(customerID)
);

CREATE TABLE organization (
    organizationID INTEGER PRIMARY KEY,
    organizationName TEXT NOT NULL UNIQUE,
    organizationPhone TEXT NOT NULL,
    organizationEmail TEXT NOT NULL,
    representativeGuestID INTEGER NOT NULL,
    FOREIGN KEY (organizationID) REFERENCES customer(customerID),
    FOREIGN KEY (representativeGuestID) REFERENCES guest(guestID)
);

CREATE TABLE Reservation (
    reservationID INTEGER PRIMARY KEY,
    reservationType TEXT NOT NULL,
    customerID INTEGER NOT NULL,
    dateResMade DATE NOT NULL,
    billingParty INTEGER NOT NULL,
    FOREIGN KEY (customerID) REFERENCES customer(customerID),
    FOREIGN KEY (billingParty) REFERENCES customer(customerID)
);

CREATE TABLE ReservationPreference (
    reservationPreferenceID INTEGER PRIMARY KEY,
    reservationID INTEGER NOT NULL,
    FOREIGN KEY (reservationID) REFERENCES Reservation(reservationID)
);

CREATE TABLE ReservationPreferenceSleeping (
    preferenceSID INTEGER PRIMARY KEY,
    checkInDate DATE NOT NULL,
    checkOutDate DATE NOT NULL,
    bedType TEXT,
    bedNum INTEGER NOT NULL,
    guestsNum INTEGER NOT NULL,
    locationPref TEXT,
    proximityPref TEXT,
    roomNum INTEGER NOT NULL,
    FOREIGN KEY (preferenceSID) REFERENCES ReservationPreference(reservationPreferenceID)
);

CREATE TABLE ReservationPreferenceMeeting (
    preferenceMID INTEGER PRIMARY KEY,
    guestNum INTEGER NOT NULL,
    usageTime TEXT NOT NULL,
    date DATE NOT NULL,
    roomNum INTEGER NOT NULL,
    FOREIGN KEY (preferenceMID) REFERENCES ReservationPreference(reservationPreferenceID)
);

CREATE TABLE RoomAssignment (
    assignmentID INTEGER PRIMARY KEY,
    reservationPreferenceID INTEGER NOT NULL,
    roomID INTEGER NOT NULL,
    FOREIGN KEY (reservationPreferenceID) REFERENCES ReservationPreference(reservationPreferenceID),
    FOREIGN KEY (roomID) REFERENCES RoomDetail(roomID)
);

CREATE TABLE Stay (
    stayID INTEGER PRIMARY KEY,
    assignmentID INTEGER NOT NULL,
    guestID INTEGER NOT NULL,
    accountID INTEGER NOT NULL,
    actualCheckIn DATETIME NOT NULL,
    actualCheckOut DATETIME,
    FOREIGN KEY (assignmentID) REFERENCES RoomAssignment(assignmentID),
    FOREIGN KEY (guestID) REFERENCES guest(guestID),
    FOREIGN KEY (accountID) REFERENCES AccountDetail(accountID)
);

-- Saanit: Events and Facility Usage

CREATE TABLE Event (
    EventID INTEGER PRIMARY KEY,
    HostGuestID INTEGER,
    HostOrganizationID INTEGER,
    EventName TEXT NOT NULL,
    EventType TEXT NOT NULL,
    StartDateTime DATETIME NOT NULL,
    EndDateTime DATETIME NOT NULL,
    EstimatedAttendance INTEGER NOT NULL,
    EstimatedHotelGuests INTEGER NOT NULL,
    FOREIGN KEY (HostGuestID) REFERENCES guest(guestID),
    FOREIGN KEY (HostOrganizationID) REFERENCES organization(organizationID)
);

CREATE TABLE EventAttendance (
    AttendanceID INTEGER PRIMARY KEY,
    EventID INTEGER NOT NULL,
    GuestID INTEGER NOT NULL,
    AttendanceStatus TEXT NOT NULL,
    CheckInTime DATETIME,
    UNIQUE (EventID, GuestID),
    FOREIGN KEY (EventID) REFERENCES Event(EventID),
    FOREIGN KEY (GuestID) REFERENCES guest(guestID)
);

CREATE TABLE MeetingTimeSlot (
    TimeSlotID INTEGER PRIMARY KEY,
    SlotName TEXT NOT NULL UNIQUE,
    StartTime TIME NOT NULL,
    EndTime TIME NOT NULL
);

CREATE TABLE EventRoomBooking (
    BookingID INTEGER PRIMARY KEY,
    EventID INTEGER NOT NULL,
    RoomID INTEGER NOT NULL,
    TimeSlotID INTEGER NOT NULL,
    BookingDate DATE NOT NULL,
    BookingStatus TEXT NOT NULL,
    FOREIGN KEY (EventID) REFERENCES Event(EventID),
    FOREIGN KEY (RoomID) REFERENCES RoomDetail(roomID),
    FOREIGN KEY (TimeSlotID) REFERENCES MeetingTimeSlot(TimeSlotID)
);

CREATE TABLE AccessCard (
    CardID INTEGER PRIMARY KEY,
    GuestID INTEGER NOT NULL,
    CardStatus TEXT NOT NULL,
    IssueDate DATE NOT NULL,
    ExpirationDate DATE NOT NULL,
    FOREIGN KEY (GuestID) REFERENCES guest(guestID)
);

CREATE TABLE AccessLog (
    AccessLogID INTEGER PRIMARY KEY,
    CardID INTEGER NOT NULL,
    RoomID INTEGER NOT NULL,
    AccessTime DATETIME NOT NULL,
    AccessDirection TEXT NOT NULL,
    AccessGranted BOOLEAN NOT NULL,
    FOREIGN KEY (CardID) REFERENCES AccessCard(CardID),
    FOREIGN KEY (RoomID) REFERENCES RoomDetail(roomID)
);

-- Roopak: Billing and Services

-- Billing contact is chosen for this account and may differ from the host or
-- organization representative. Account status is a staff-managed lifecycle state.
CREATE TABLE AccountDetail (
    accountID INTEGER PRIMARY KEY,
    billingContactGuestID INTEGER NOT NULL,
    orgID INTEGER,
    eventID INTEGER,
    depositRequired BOOLEAN NOT NULL,
    creditLimit FLOAT NOT NULL,
    status TEXT NOT NULL,
    startDate DATE NOT NULL,
    closedDate DATE,
    CHECK (orgID IS NULL OR eventID IS NULL),
    FOREIGN KEY (billingContactGuestID) REFERENCES guest(guestID),
    FOREIGN KEY (orgID) REFERENCES organization(organizationID),
    FOREIGN KEY (eventID) REFERENCES Event(EventID)
);

CREATE TABLE Invoice (
    invoiceID INTEGER PRIMARY KEY,
    accountID INTEGER NOT NULL,
    issueDate DATE NOT NULL,
    dueDate DATE NOT NULL,
    periodStart DATE NOT NULL,
    periodEnd DATE NOT NULL,
    taxRate FLOAT NOT NULL,
    status TEXT NOT NULL,
    FOREIGN KEY (accountID) REFERENCES AccountDetail(accountID)
);

CREATE TABLE Service (
    serviceID INTEGER PRIMARY KEY,
    serviceName TEXT NOT NULL UNIQUE,
    category TEXT NOT NULL,
    unit TEXT NOT NULL,
    isTaxable BOOLEAN NOT NULL,
    unitPrice FLOAT NOT NULL
);

-- guestID identifies the person incurring this charge, who can differ from
-- the registered occupant. unitPrice is the actual price for this transaction.
CREATE TABLE Charge (
    chargeID INTEGER PRIMARY KEY,
    serviceID INTEGER NOT NULL,
    guestID INTEGER NOT NULL,
    stayID INTEGER,
    bookingID INTEGER,
    chargeDatetime DATETIME NOT NULL,
    quantity FLOAT NOT NULL,
    unitPrice FLOAT NOT NULL,
    chargeStatus TEXT NOT NULL,
    description TEXT,
    FOREIGN KEY (serviceID) REFERENCES Service(serviceID),
    FOREIGN KEY (guestID) REFERENCES guest(guestID),
    FOREIGN KEY (stayID) REFERENCES Stay(stayID),
    FOREIGN KEY (bookingID) REFERENCES EventRoomBooking(BookingID)
);

CREATE TABLE PaymentEntry (
    paymentID INTEGER PRIMARY KEY,
    unbilledAccountID INTEGER,
    invoiceID INTEGER,
    paymentDate DATETIME NOT NULL,
    amount FLOAT NOT NULL,
    method TEXT NOT NULL,
    deposit BOOLEAN NOT NULL,
    referenceNumber TEXT NOT NULL UNIQUE,
    CHECK ((invoiceID IS NULL) <> (unbilledAccountID IS NULL)),
    FOREIGN KEY (unbilledAccountID) REFERENCES AccountDetail(accountID),
    FOREIGN KEY (invoiceID) REFERENCES Invoice(invoiceID)
);

CREATE TABLE AllocationEntry (
    allocationID INTEGER PRIMARY KEY,
    chargeID INTEGER NOT NULL,
    unbilledAccountID INTEGER,
    invoiceID INTEGER,
    splitPercent FLOAT NOT NULL,
    FOREIGN KEY (chargeID) REFERENCES Charge(chargeID),
    CHECK ((invoiceID IS NULL) <> (unbilledAccountID IS NULL)),
    FOREIGN KEY (unbilledAccountID) REFERENCES AccountDetail(accountID),
    FOREIGN KEY (invoiceID) REFERENCES Invoice(invoiceID)
);

-- Reporting views expose the original column names. Write to the base tables.
CREATE VIEW Room AS
SELECT r.roomID, r.wingID, r.roomNumber, r.roomType, c.bedType,
       r.hasToilet, r.hasBath, r.sleepingCapacity, r.meetingCapacity,
       r.largeExtraSpace, r.smokingStatus, r.baseRate, r.roomStatus
FROM RoomDetail AS r JOIN RoomCategory AS c ON c.roomType = r.roomType;

CREATE VIEW BillingAccount AS
SELECT accountID, billingContactGuestID AS guestID, orgID, eventID,
       CASE WHEN eventID IS NOT NULL THEN 'Event'
            WHEN orgID IS NOT NULL THEN 'Organization'
            ELSE 'Individual' END AS accountType,
       depositRequired, creditLimit, status, startDate, closedDate
FROM AccountDetail;

-- Invoiced entries inherit the invoice account. Deposits and pending charges
-- point directly to an account until an invoice is assigned.
CREATE VIEW Payment AS
SELECT p.paymentID, COALESCE(i.accountID, p.unbilledAccountID) AS accountID,
       p.invoiceID, p.paymentDate, p.amount, p.method, p.deposit, p.referenceNumber
FROM PaymentEntry AS p LEFT JOIN Invoice AS i ON i.invoiceID = p.invoiceID;

CREATE VIEW ChargeAllocation AS
SELECT a.allocationID, a.chargeID, COALESCE(i.accountID, a.unbilledAccountID) AS accountID,
       a.invoiceID, a.splitPercent
FROM AllocationEntry AS a LEFT JOIN Invoice AS i ON i.invoiceID = a.invoiceID;

-- Eric — Hotel structure and rooms

INSERT INTO Hotel (hotelID, hotelName) VALUES
(1, 'Last Resort Lake Tahoe'),
(2, 'Last Resort Sedona');

INSERT INTO Building (buildingID, buildingName, hotelID) VALUES
(1, 'Main Lodge', 1),
(2, 'Lakeside Pavilion', 1),
(3, 'Canyon House', 2),
(4, 'Mesa Lodge', 2);

INSERT INTO Wings (wingID, wingName, buildingID, nearPool, nearGarage, handicapAccess) VALUES
(1, 'North', 1, 1, 0, 1),
(2, 'South', 1, 0, 1, 1),
(3, 'East', 2, 1, 0, 1),
(4, 'West', 3, 0, 1, 1),
(5, 'Courtyard', 4, 1, 0, 1);

INSERT INTO RoomCategory (roomType, bedType) VALUES
('Ballroom', 'None'),
('Courtyard', 'None'),
('Meeting', 'None'),
('Pool Patio', 'None'),
('Sleeping', 'Permanent'),
('Suite', 'Foldaway');

INSERT INTO RoomDetail (roomID, wingID, roomNumber, roomType, hasToilet, hasBath, sleepingCapacity, meetingCapacity, largeExtraSpace, smokingStatus, baseRate, roomStatus) VALUES
(1, 1, '101', 'Sleeping', 1, 1, 2, 0, 0, 'Non-Smoking', 199.0, 'Available'),
(2, 1, '102', 'Sleeping', 1, 1, 4, 0, 0, 'Non-Smoking', 229.0, 'Available'),
(3, 1, '103', 'Sleeping', 1, 1, 2, 0, 0, 'Non-Smoking', 199.0, 'Available'),
(4, 1, '104', 'Sleeping', 1, 1, 4, 0, 0, 'Non-Smoking', 229.0, 'Under Repair'),
(5, 1, '105', 'Sleeping', 1, 1, 2, 0, 0, 'Non-Smoking', 199.0, 'Available'),
(6, 1, '106', 'Sleeping', 1, 1, 4, 0, 0, 'Non-Smoking', 229.0, 'Available'),
(7, 2, '111', 'Sleeping', 1, 1, 2, 0, 0, 'Non-Smoking', 209.0, 'Available'),
(8, 2, '112', 'Sleeping', 1, 1, 4, 0, 0, 'Non-Smoking', 239.0, 'Available'),
(9, 2, '115', 'Suite', 1, 1, 4, 15, 1, 'Non-Smoking', 389.0, 'Available'),
(10, 3, '130', 'Ballroom', 1, 0, 0, 220, 1, 'Non-Smoking', 1500.0, 'Available'),
(11, 3, '131', 'Ballroom', 1, 0, 0, 160, 1, 'Non-Smoking', 1200.0, 'Available'),
(12, 3, '132', 'Meeting', 1, 0, 0, 20, 0, 'Non-Smoking', 350.0, 'Available'),
(13, 3, 'PAT1', 'Pool Patio', 0, 0, 0, 90, 1, 'Non-Smoking', 600.0, 'Available'),
(14, 4, '101', 'Sleeping', 1, 1, 2, 0, 0, 'Non-Smoking', 179.0, 'Available'),
(15, 4, '102', 'Sleeping', 1, 1, 4, 0, 0, 'Non-Smoking', 209.0, 'Available'),
(16, 4, '103', 'Sleeping', 1, 1, 2, 0, 0, 'Non-Smoking', 179.0, 'Available'),
(17, 4, '104', 'Sleeping', 1, 1, 4, 0, 0, 'Non-Smoking', 209.0, 'Renovation'),
(18, 5, '120', 'Suite', 1, 1, 4, 20, 1, 'Non-Smoking', 349.0, 'Available'),
(19, 5, '121', 'Meeting', 1, 0, 0, 40, 0, 'Non-Smoking', 300.0, 'Available'),
(20, 5, 'CY1', 'Courtyard', 0, 0, 0, 100, 1, 'Non-Smoking', 500.0, 'Available');

INSERT INTO roomBed (roomID, bedSize, bedQuantity) VALUES
(1, 'King', 1),
(2, 'Queen', 2),
(3, 'King', 1),
(4, 'Queen', 2),
(5, 'King', 1),
(6, 'Queen', 2),
(7, 'King', 1),
(8, 'Queen', 2),
(9, 'King', 1),
(9, 'Regular', 1),
(14, 'King', 1),
(15, 'Queen', 2),
(16, 'King', 1),
(17, 'Queen', 2),
(18, 'King', 1),
(18, 'Regular', 1);

INSERT INTO roomAdjacency (roomID1, roomID2, isMovableWall) VALUES
(1, 2, 0),
(3, 4, 0),
(8, 9, 0),
(10, 11, 1),
(11, 12, 0),
(14, 15, 0),
(16, 17, 0),
(18, 19, 0);

-- Ava — Guests and reservations

INSERT INTO customer (customerID, customerType) VALUES
(1, 'Guest'),
(2, 'Guest'),
(3, 'Guest'),
(4, 'Guest'),
(5, 'Guest'),
(6, 'Guest'),
(7, 'Guest'),
(8, 'Guest'),
(9, 'Guest'),
(10, 'Guest'),
(11, 'Guest'),
(12, 'Guest'),
(13, 'Guest'),
(14, 'Guest'),
(15, 'Guest'),
(16, 'Organization'),
(17, 'Organization'),
(18, 'Organization'),
(19, 'Organization'),
(20, 'Organization');

INSERT INTO guest (guestID, guestFirstName, guestLastName, guestPhone, guestEmail) VALUES
(1, 'Maya', 'Chen', '303-555-2571', 'maya.chen1@icloud.com'),
(2, 'Daniel', 'Silva', '312-555-0891', 'daniel.silva2@gmail.com'),
(3, 'Priya', 'Petrova', '702-555-8879', 'priya.petrova3@gmail.com'),
(4, 'James', 'Romero', '303-555-9648', 'james.romero4@gmail.com'),
(5, 'Sofia', 'Moreau', '480-555-3617', 'sofia.moreau5@gmail.com'),
(6, 'Ethan', 'Whitfield', '646-555-7204', 'ethan.whitfield6@icloud.com'),
(7, 'Aisha', 'Kim', '646-555-4043', 'aisha.kim7@gmail.com'),
(8, 'Lucas', 'Brooks', '480-555-7055', 'lucas.brooks8@gmail.com'),
(9, 'Grace', 'Rossi', '702-555-9364', 'grace.rossi9@gmail.com'),
(10, 'Omar', 'Sato', '718-555-9651', 'omar.sato10@gmail.com'),
(11, 'Hannah', 'Khan', '602-555-9693', 'hannah.khan11@icloud.com'),
(12, 'Mateo', 'Murphy', '212-555-3722', 'mateo.murphy12@gmail.com'),
(13, 'Chloe', 'Walsh', '480-555-2281', 'chloe.walsh13@outlook.com'),
(14, 'Ryan', 'Hayes', '305-555-2463', 'ryan.hayes14@gmail.com'),
(15, 'Nina', 'Nair', '602-555-5154', 'nina.nair15@yahoo.com');

INSERT INTO organization (organizationID, organizationName, organizationPhone, organizationEmail, representativeGuestID) VALUES
(16, 'Northwind Analytics', '415-555-0100', 'events@northwind.com', 2),
(17, 'Bluepeak Medical', '303-555-0110', 'travel@bluepeak.org', 10),
(18, 'Harbor & Co. Law', '305-555-0120', 'admin@harborlaw.com', 14),
(19, 'Sierra Tech Society', '775-555-0130', 'board@sierratech.org', 11),
(20, 'Summit Pharma', '617-555-0160', 'meetings@summitpharma.com', 4);

INSERT INTO Reservation (reservationID, reservationType, customerID, dateResMade, billingParty) VALUES
(1, 'Both', 16, '2026-06-20', 16),
(2, 'Both', 10, '2026-07-12', 10),
(3, 'Meeting', 19, '2026-08-21', 19),
(4, 'Both', 17, '2026-07-26', 17),
(5, 'Both', 12, '2026-09-23', 12),
(6, 'Sleeping', 15, '2026-06-25', 15),
(7, 'Sleeping', 1, '2026-07-12', 1),
(8, 'Sleeping', 3, '2026-08-11', 19),
(9, 'Sleeping', 1, '2026-08-26', 1),
(10, 'Sleeping', 12, '2026-10-08', 12),
(11, 'Sleeping', 1, '2026-09-18', 16),
(12, 'Sleeping', 5, '2026-10-16', 5),
(13, 'Sleeping', 5, '2026-09-19', 5),
(14, 'Sleeping', 15, '2026-10-17', 15),
(15, 'Sleeping', 2, '2026-08-18', 2),
(16, 'Sleeping', 4, '2026-08-25', 4),
(17, 'Sleeping', 6, '2026-09-03', 6),
(18, 'Sleeping', 8, '2026-09-14', 8),
(19, 'Sleeping', 11, '2026-09-25', 11),
(20, 'Sleeping', 14, '2026-09-29', 14),
(21, 'Sleeping', 2, '2026-10-05', 2),
(22, 'Sleeping', 4, '2026-10-14', 4),
(23, 'Sleeping', 6, '2026-10-24', 6),
(24, 'Sleeping', 8, '2026-11-02', 8);

INSERT INTO ReservationPreference (reservationPreferenceID, reservationID) VALUES
(1, 1),
(2, 1),
(3, 1),
(4, 2),
(5, 2),
(6, 2),
(7, 3),
(8, 4),
(9, 4),
(10, 5),
(11, 5),
(12, 5),
(13, 6),
(14, 7),
(15, 8),
(16, 9),
(17, 10),
(18, 11),
(19, 12),
(20, 13),
(21, 14),
(22, 15),
(23, 16),
(24, 17),
(25, 18),
(26, 19),
(27, 20),
(28, 21),
(29, 22),
(30, 23),
(31, 24);

INSERT INTO ReservationPreferenceSleeping (preferenceSID, checkInDate, checkOutDate, bedType, bedNum, guestsNum, locationPref, proximityPref, roomNum) VALUES
(3, '2026-09-14', '2026-09-16', 'King', 1, 2, NULL, 'Near conference rooms', 1),
(6, '2026-10-03', '2026-10-04', 'King', 1, 2, 'Quiet floor', 'Near conference rooms', 1),
(9, '2026-11-05', '2026-11-06', 'King', 1, 2, NULL, 'Near conference rooms', 1),
(12, '2026-11-28', '2026-11-29', 'King', 1, 2, 'Ground floor', 'Near conference rooms', 1),
(13, '2026-09-04', '2026-09-07', 'King', 1, 1, NULL, 'Near conference rooms', 1),
(14, '2026-09-12', '2026-09-13', 'Queen', 2, 3, NULL, NULL, 1),
(15, '2026-09-24', '2026-09-27', 'King', 1, 2, 'Ground floor', NULL, 1),
(16, '2026-10-04', '2026-10-08', 'King', 1, 2, NULL, 'Near conference rooms', 1),
(17, '2026-10-17', '2026-10-20', 'King', 1, 1, NULL, NULL, 1),
(18, '2026-10-25', '2026-10-27', 'King', 1, 1, NULL, NULL, 1),
(19, '2026-11-02', '2026-11-06', 'King', 1, 1, 'Quiet floor', 'Near elevator', 1),
(20, '2026-11-11', '2026-11-15', 'Queen', 2, 4, 'Near parking', 'Near conference rooms', 1),
(21, '2026-11-21', '2026-11-23', 'King', 1, 2, NULL, NULL, 1),
(22, '2026-09-01', '2026-09-04', 'King', 1, 1, NULL, NULL, 1),
(23, '2026-09-08', '2026-09-10', 'Queen', 2, 1, NULL, NULL, 1),
(24, '2026-09-17', '2026-09-20', 'King', 1, 1, NULL, NULL, 1),
(25, '2026-09-28', '2026-09-30', 'King', 1, 1, NULL, NULL, 1),
(26, '2026-10-09', '2026-10-12', 'Queen', 2, 1, NULL, NULL, 1),
(27, '2026-10-13', '2026-10-15', 'King', 1, 1, NULL, NULL, 1),
(28, '2026-10-19', '2026-10-23', 'King', 1, 1, NULL, NULL, 1),
(29, '2026-10-28', '2026-10-31', 'King', 1, 1, NULL, NULL, 1),
(30, '2026-11-07', '2026-11-09', 'Queen', 2, 1, NULL, NULL, 1),
(31, '2026-11-16', '2026-11-18', 'King', 1, 1, NULL, NULL, 1);

INSERT INTO ReservationPreferenceMeeting (preferenceMID, guestNum, usageTime, date, roomNum) VALUES
(1, 150, 'Morning', '2026-09-15', 1),
(2, 150, 'Lunch', '2026-09-15', 1),
(4, 140, 'Afternoon', '2026-10-03', 1),
(5, 140, 'Supper', '2026-10-03', 1),
(7, 80, 'Supper', '2026-10-17', 1),
(8, 12, 'Morning', '2026-11-05', 1),
(10, 160, 'Supper', '2026-11-28', 1),
(11, 160, 'Evening', '2026-11-28', 1);

INSERT INTO RoomAssignment (assignmentID, reservationPreferenceID, roomID) VALUES
(1, 1, 10),
(2, 2, 10),
(3, 3, 7),
(4, 4, 13),
(5, 5, 10),
(6, 6, 7),
(7, 7, 20),
(8, 8, 19),
(9, 9, 14),
(10, 10, 10),
(11, 11, 11),
(12, 12, 7),
(13, 13, 5),
(14, 14, 6),
(15, 15, 14),
(16, 16, 5),
(17, 18, 14),
(18, 19, 16),
(19, 20, 15),
(20, 21, 7),
(21, 22, 1),
(22, 23, 2),
(23, 24, 18),
(24, 25, 3),
(25, 26, 8),
(26, 27, 9),
(27, 28, 18),
(28, 29, 1),
(29, 30, 2),
(30, 31, 18);

-- Saanit — Events and facility usage

INSERT INTO Event (EventID, HostGuestID, HostOrganizationID, EventName, EventType, StartDateTime, EndDateTime, EstimatedAttendance, EstimatedHotelGuests) VALUES
(1, NULL, 16, 'Northwind Data Summit', 'Conference', '2026-09-15 09:00:00', '2026-09-15 14:00:00', 150, 40),
(2, 10, NULL, 'Patel-Brooks Wedding', 'Wedding', '2026-10-03 14:00:00', '2026-10-03 20:00:00', 140, 30),
(3, NULL, 19, 'Sierra Tech Annual Mixer', 'Party', '2026-10-17 17:30:00', '2026-10-17 20:00:00', 80, 10),
(4, NULL, 17, 'Bluepeak Board Retreat', 'Meeting', '2026-11-05 09:00:00', '2026-11-05 12:00:00', 12, 8),
(5, 12, NULL, 'Nguyen-Lopez Wedding', 'Wedding', '2026-11-28 17:30:00', '2026-11-28 23:00:00', 160, 35);

INSERT INTO EventAttendance (AttendanceID, EventID, GuestID, AttendanceStatus, CheckInTime) VALUES
(1, 1, 13, 'Checked In', '2026-09-15 08:46:00'),
(2, 1, 6, 'Checked In', '2026-09-15 08:53:00'),
(3, 1, 8, 'Checked In', '2026-09-15 08:38:00'),
(4, 1, 10, 'Checked In', '2026-09-15 08:58:00'),
(5, 2, 10, 'Checked In', '2026-10-03 13:39:00'),
(6, 2, 5, 'Checked In', '2026-10-03 13:37:00'),
(7, 2, 8, 'Checked In', '2026-10-03 13:40:00'),
(8, 2, 13, 'Checked In', '2026-10-03 13:39:00'),
(9, 3, 3, 'Checked In', '2026-10-17 17:23:00'),
(10, 3, 2, 'Checked In', '2026-10-17 17:30:00'),
(11, 4, 9, 'Checked In', '2026-11-05 08:50:00'),
(12, 4, 6, 'Cancelled', NULL),
(13, 4, 10, 'Checked In', '2026-11-05 08:44:00'),
(14, 4, 13, 'Cancelled', NULL),
(15, 5, 12, 'Registered', NULL),
(16, 5, 8, 'Registered', NULL),
(17, 5, 2, 'Registered', NULL),
(18, 5, 14, 'Registered', NULL),
(19, 5, 15, 'Registered', NULL);

INSERT INTO MeetingTimeSlot (TimeSlotID, SlotName, StartTime, EndTime) VALUES
(1, 'Breakfast', '06:30:00', '09:00:00'),
(2, 'Morning', '09:00:00', '12:00:00'),
(3, 'Lunch', '12:00:00', '14:00:00'),
(4, 'Afternoon', '14:00:00', '17:30:00'),
(5, 'Supper', '17:30:00', '20:00:00'),
(6, 'Evening', '20:00:00', '23:00:00'),
(7, 'Night', '23:00:00', '23:59:00');

INSERT INTO EventRoomBooking (BookingID, EventID, RoomID, TimeSlotID, BookingDate, BookingStatus) VALUES
(1, 1, 10, 2, '2026-09-15', 'Confirmed'),
(2, 1, 10, 3, '2026-09-15', 'Confirmed'),
(3, 2, 13, 4, '2026-10-03', 'Confirmed'),
(4, 2, 10, 5, '2026-10-03', 'Confirmed'),
(5, 3, 20, 5, '2026-10-17', 'Confirmed'),
(6, 4, 19, 2, '2026-11-05', 'Confirmed'),
(7, 5, 10, 5, '2026-11-28', 'Confirmed'),
(8, 5, 11, 6, '2026-11-28', 'Tentative');

INSERT INTO AccessCard (CardID, GuestID, CardStatus, IssueDate, ExpirationDate) VALUES
(1, 13, 'Expired', '2026-09-14', '2026-09-16'),
(2, 10, 'Expired', '2026-10-03', '2026-10-04'),
(3, 9, 'Expired', '2026-11-05', '2026-11-06'),
(4, 15, 'Expired', '2026-09-04', '2026-09-07'),
(5, 1, 'Expired', '2026-09-12', '2026-09-13'),
(6, 3, 'Expired', '2026-09-24', '2026-09-27'),
(7, 1, 'Expired', '2026-10-04', '2026-10-08'),
(8, 1, 'Expired', '2026-10-25', '2026-10-27'),
(9, 5, 'Expired', '2026-11-02', '2026-11-06'),
(10, 5, 'Expired', '2026-11-11', '2026-11-15');

INSERT INTO AccessLog (AccessLogID, CardID, RoomID, AccessTime, AccessDirection, AccessGranted) VALUES
(1, 4, 5, '2026-09-04 19:41:00', 'In', 1),
(2, 5, 6, '2026-09-12 17:11:00', 'In', 1),
(3, 1, 7, '2026-09-14 18:00:00', 'In', 1),
(4, 1, 10, '2026-09-15 08:54:00', 'In', 1),
(5, 1, 7, '2026-09-16 08:47:00', 'Out', 1),
(6, 6, 14, '2026-09-24 16:09:00', 'In', 1),
(7, 2, 13, '2026-10-03 13:45:00', 'In', 1),
(8, 2, 7, '2026-10-03 15:46:00', 'In', 1),
(9, 2, 7, '2026-10-04 12:15:00', 'In', 0),
(10, 7, 5, '2026-10-04 16:21:00', 'In', 1),
(11, 8, 14, '2026-10-25 15:46:00', 'In', 1),
(12, 9, 16, '2026-11-02 17:15:00', 'In', 1),
(13, 3, 19, '2026-11-05 08:58:00', 'In', 1),
(14, 3, 14, '2026-11-05 18:46:00', 'In', 1),
(15, 3, 14, '2026-11-06 10:56:00', 'Out', 1),
(16, 9, 16, '2026-11-06 12:05:00', 'In', 0),
(17, 10, 15, '2026-11-11 19:11:00', 'In', 1),
(18, 10, 15, '2026-11-15 11:40:00', 'In', 0);

-- Roopak — Billing accounts

INSERT INTO AccountDetail (accountID, billingContactGuestID, orgID, eventID, depositRequired, creditLimit, status, startDate, closedDate) VALUES
(1, 2, NULL, 1, 1, 10000.0, 'Closed', '2026-06-20', '2026-10-22'),
(2, 13, NULL, NULL, 0, 5000.0, 'Open', '2026-06-20', NULL),
(3, 10, NULL, 2, 1, 30000.0, 'Open', '2026-07-12', NULL),
(4, 10, NULL, NULL, 0, 3000.0, 'Open', '2026-07-12', NULL),
(5, 11, NULL, 3, 1, 20000.0, 'Closed', '2026-08-21', '2026-11-14'),
(6, 10, NULL, 4, 1, 30000.0, 'Open', '2026-07-26', NULL),
(7, 9, NULL, NULL, 0, 5000.0, 'Closed', '2026-07-26', '2026-11-06'),
(8, 12, NULL, 5, 1, 30000.0, 'Open', '2026-09-23', NULL),
(9, 12, NULL, NULL, 0, 1500.0, 'Open', '2026-09-23', NULL),
(10, 15, NULL, NULL, 0, 1500.0, 'Closed', '2026-06-25', '2026-09-07'),
(11, 1, NULL, NULL, 0, 5000.0, 'Closed', '2026-07-12', '2026-10-08'),
(12, 11, 19, NULL, 1, 50000.0, 'Open', '2026-08-11', NULL),
(13, 3, NULL, NULL, 0, 2000.0, 'Closed', '2026-08-11', '2026-09-27'),
(14, 2, 16, NULL, 1, 50000.0, 'Open', '2026-09-18', NULL),
(15, 5, NULL, NULL, 0, 5000.0, 'Closed', '2026-09-19', '2026-11-15'),
(16, 7, NULL, NULL, 1, 5000.0, 'Closed', '2026-09-19', '2026-11-15'),
(17, 2, NULL, NULL, 0, 5000.0, 'Closed', '2026-08-18', '2026-09-04'),
(18, 4, NULL, NULL, 0, 5000.0, 'Closed', '2026-08-25', '2026-09-10'),
(19, 6, NULL, NULL, 0, 5000.0, 'Closed', '2026-09-03', '2026-09-20'),
(20, 8, NULL, NULL, 0, 5000.0, 'Closed', '2026-09-14', '2026-09-30'),
(21, 11, NULL, NULL, 0, 5000.0, 'Closed', '2026-09-25', '2026-10-12'),
(22, 14, NULL, NULL, 0, 5000.0, 'Closed', '2026-09-29', '2026-10-15'),
(23, 2, NULL, NULL, 0, 5000.0, 'Closed', '2026-10-05', '2026-10-23'),
(24, 4, NULL, NULL, 0, 5000.0, 'Closed', '2026-10-14', '2026-10-31'),
(25, 6, NULL, NULL, 0, 5000.0, 'Closed', '2026-10-24', '2026-11-09'),
(26, 8, NULL, NULL, 0, 5000.0, 'Closed', '2026-11-02', '2026-11-18');

-- Ava — Completed stays

INSERT INTO Stay (stayID, assignmentID, guestID, accountID, actualCheckIn, actualCheckOut) VALUES
(1, 3, 13, 1, '2026-09-14 17:45:00', '2026-09-16 09:05:00'),
(2, 6, 10, 3, '2026-10-03 15:35:00', '2026-10-04 10:15:00'),
(3, 9, 9, 6, '2026-11-05 18:35:00', '2026-11-06 11:05:00'),
(4, 13, 15, 10, '2026-09-04 19:20:00', '2026-09-07 10:30:00'),
(5, 14, 1, 11, '2026-09-12 17:00:00', '2026-09-13 10:05:00'),
(6, 15, 3, 12, '2026-09-24 16:00:00', '2026-09-27 10:55:00'),
(7, 16, 1, 11, '2026-10-04 16:00:00', '2026-10-08 11:30:00'),
(8, 17, 1, 14, '2026-10-25 15:35:00', '2026-10-27 10:55:00'),
(9, 18, 5, 15, '2026-11-02 16:50:00', '2026-11-06 10:05:00'),
(10, 19, 5, 15, '2026-11-11 18:50:00', '2026-11-15 09:40:00'),
(11, 21, 2, 17, '2026-09-01 16:00:00', '2026-09-04 10:00:00'),
(12, 22, 4, 18, '2026-09-08 16:00:00', '2026-09-10 10:00:00'),
(13, 23, 6, 19, '2026-09-17 16:00:00', '2026-09-20 10:00:00'),
(14, 24, 8, 20, '2026-09-28 16:00:00', '2026-09-30 10:00:00'),
(15, 25, 11, 21, '2026-10-09 16:00:00', '2026-10-12 10:00:00'),
(16, 26, 14, 22, '2026-10-13 16:00:00', '2026-10-15 10:00:00'),
(17, 27, 2, 23, '2026-10-19 16:00:00', '2026-10-23 10:00:00'),
(18, 28, 4, 24, '2026-10-28 16:00:00', '2026-10-31 10:00:00'),
(19, 29, 6, 25, '2026-11-07 16:00:00', '2026-11-09 10:00:00'),
(20, 30, 8, 26, '2026-11-16 16:00:00', '2026-11-18 10:00:00');

-- Roopak — Services and billing

INSERT INTO Service (serviceID, serviceName, category, unit, isTaxable, unitPrice) VALUES
(1, 'Room Night', 'Room', 'Night', 1, 199.0),
(2, 'Meeting Room Rental', 'Meeting Room', 'Slot', 1, 400.0),
(3, 'Breakfast', 'Food & Beverage', 'Item', 1, 24.0),
(4, 'Restaurant Dinner', 'Food & Beverage', 'Item', 1, 62.5),
(5, 'Banquet Catering', 'Food & Beverage', 'Item', 1, 55.0),
(6, 'Bar Tab', 'Food & Beverage', 'Item', 1, 14.0),
(7, 'Long-Distance Call', 'Communications', 'Minute', 0, 0.45),
(8, 'Spa Massage', 'Spa', 'Session', 1, 140.0),
(9, 'Parking', 'Other', 'Night', 1, 25.0),
(10, 'Late Checkout', 'Other', 'Hour', 1, 35.0);

INSERT INTO Charge (chargeID, serviceID, guestID, stayID, bookingID, chargeDatetime, quantity, unitPrice, chargeStatus, description) VALUES
(1, 2, 2, NULL, 1, '2026-09-15 12:00:00', 1.0, 1500.0, 'Billed', '130 (Ballroom), Morning'),
(2, 2, 2, NULL, 2, '2026-09-15 14:00:00', 1.0, 750.0, 'Billed', '130 (Ballroom), Lunch'),
(3, 1, 13, 1, NULL, '2026-09-16 09:05:00', 2.0, 209.0, 'Billed', 'Room 111, 2 nights'),
(4, 2, 10, NULL, 3, '2026-10-03 17:30:00', 1.0, 600.0, 'Billed', 'PAT1 (Pool Patio), Afternoon'),
(5, 2, 10, NULL, 4, '2026-10-03 20:00:00', 1.0, 750.0, 'Billed', '130 (Ballroom), Supper'),
(6, 1, 10, 2, NULL, '2026-10-04 10:15:00', 1.0, 209.0, 'Billed', 'Room 111, 1 night'),
(7, 2, 11, NULL, 5, '2026-10-17 20:00:00', 1.0, 250.0, 'Billed', 'CY1 (Courtyard), Supper'),
(8, 2, 10, NULL, 6, '2026-11-05 12:00:00', 1.0, 300.0, 'Posted', '121 (Meeting), Morning'),
(9, 1, 9, 3, NULL, '2026-11-06 11:05:00', 1.0, 179.0, 'Posted', 'Room 101, 1 night'),
(10, 3, 9, 3, NULL, '2026-11-06 04:35:00', 1.0, 24.0, 'Billed', 'Lodge cafe breakfast'),
(11, 6, 9, 3, NULL, '2026-11-05 21:35:00', 3.0, 14.0, 'Billed', 'Lobby bar'),
(12, 1, 15, 4, NULL, '2026-09-07 10:30:00', 3.0, 199.0, 'Billed', 'Room 105, 3 nights'),
(13, 1, 1, 5, NULL, '2026-09-13 10:05:00', 1.0, 229.0, 'Billed', 'Room 106, 1 night'),
(14, 3, 1, 5, NULL, '2026-09-13 08:00:00', 3.0, 24.0, 'Billed', 'Lodge cafe breakfast'),
(15, 1, 3, 6, NULL, '2026-09-27 10:55:00', 3.0, 179.0, 'Billed', 'Room 101, 3 nights'),
(16, 8, 3, 6, NULL, '2026-09-25 06:00:00', 1.0, 140.0, 'Billed', '60-min massage'),
(17, 1, 1, 7, NULL, '2026-10-08 11:30:00', 4.0, 199.0, 'Billed', 'Room 105, 4 nights'),
(18, 4, 1, 7, NULL, '2026-10-07 10:00:00', 1.0, 62.5, 'Billed', 'Dinner, main restaurant'),
(19, 1, 1, 8, NULL, '2026-10-27 10:55:00', 2.0, 179.0, 'Billed', 'Room 101, 2 nights'),
(20, 1, 5, 9, NULL, '2026-11-06 10:05:00', 4.0, 179.0, 'Billed', 'Room 103, 4 nights'),
(21, 1, 5, 10, NULL, '2026-11-15 09:40:00', 4.0, 209.0, 'Billed', 'Room 102, 4 nights'),
(22, 1, 2, 11, NULL, '2026-09-04 10:00:00', 3.0, 199.0, 'Billed', 'Room nights'),
(23, 1, 4, 12, NULL, '2026-09-10 10:00:00', 2.0, 229.0, 'Billed', 'Room nights'),
(24, 1, 6, 13, NULL, '2026-09-20 10:00:00', 3.0, 349.0, 'Billed', 'Room nights'),
(25, 1, 8, 14, NULL, '2026-09-30 10:00:00', 2.0, 199.0, 'Billed', 'Room nights'),
(26, 1, 11, 15, NULL, '2026-10-12 10:00:00', 3.0, 239.0, 'Billed', 'Room nights'),
(27, 1, 14, 16, NULL, '2026-10-15 10:00:00', 2.0, 389.0, 'Billed', 'Room nights'),
(28, 1, 2, 17, NULL, '2026-10-23 10:00:00', 4.0, 349.0, 'Billed', 'Room nights'),
(29, 1, 4, 18, NULL, '2026-10-31 10:00:00', 3.0, 199.0, 'Billed', 'Room nights'),
(30, 1, 6, 19, NULL, '2026-11-09 10:00:00', 2.0, 229.0, 'Billed', 'Room nights'),
(31, 1, 8, 20, NULL, '2026-11-18 10:00:00', 2.0, 349.0, 'Billed', 'Room nights');

INSERT INTO Invoice (invoiceID, accountID, issueDate, dueDate, periodStart, periodEnd, taxRate, status) VALUES
(1, 10, '2026-09-07', '2026-09-21', '2026-09-04', '2026-09-07', 0.08, 'Paid'),
(2, 11, '2026-09-13', '2026-09-27', '2026-09-12', '2026-09-13', 0.08, 'Paid'),
(3, 13, '2026-09-27', '2026-10-11', '2026-09-24', '2026-09-27', 0.08, 'Paid'),
(4, 11, '2026-10-08', '2026-10-22', '2026-10-04', '2026-10-08', 0.08, 'Paid'),
(5, 15, '2026-11-06', '2026-11-20', '2026-11-02', '2026-11-06', 0.08, 'Paid'),
(6, 7, '2026-11-06', '2026-11-20', '2026-11-05', '2026-11-06', 0.08, 'Paid'),
(7, 15, '2026-11-15', '2026-11-29', '2026-11-11', '2026-11-15', 0.08, 'Paid'),
(8, 16, '2026-11-15', '2026-11-29', '2026-11-11', '2026-11-15', 0.08, 'Paid'),
(9, 1, '2026-10-01', '2026-10-31', '2026-09-01', '2026-09-30', 0.08, 'Paid'),
(10, 3, '2026-11-01', '2026-12-01', '2026-10-01', '2026-10-31', 0.08, 'Issued'),
(11, 5, '2026-11-01', '2026-12-01', '2026-10-01', '2026-10-31', 0.08, 'Paid'),
(12, 12, '2026-10-01', '2026-10-31', '2026-09-01', '2026-09-30', 0.08, 'Paid'),
(13, 14, '2026-11-01', '2026-12-01', '2026-10-01', '2026-10-31', 0.08, 'Issued'),
(14, 17, '2026-09-04', '2026-09-18', '2026-09-01', '2026-09-04', 0.08, 'Paid'),
(15, 18, '2026-09-10', '2026-09-24', '2026-09-08', '2026-09-10', 0.08, 'Paid'),
(16, 19, '2026-09-20', '2026-10-04', '2026-09-17', '2026-09-20', 0.08, 'Paid'),
(17, 20, '2026-09-30', '2026-10-14', '2026-09-28', '2026-09-30', 0.08, 'Paid'),
(18, 21, '2026-10-12', '2026-10-26', '2026-10-09', '2026-10-12', 0.08, 'Paid'),
(19, 22, '2026-10-15', '2026-10-29', '2026-10-13', '2026-10-15', 0.08, 'Paid'),
(20, 23, '2026-10-23', '2026-11-06', '2026-10-19', '2026-10-23', 0.08, 'Paid'),
(21, 24, '2026-10-31', '2026-11-14', '2026-10-28', '2026-10-31', 0.08, 'Paid'),
(22, 25, '2026-11-09', '2026-11-23', '2026-11-07', '2026-11-09', 0.08, 'Paid'),
(23, 26, '2026-11-18', '2026-12-02', '2026-11-16', '2026-11-18', 0.08, 'Paid');

INSERT INTO PaymentEntry (paymentID, unbilledAccountID, invoiceID, paymentDate, amount, method, deposit, referenceNumber) VALUES
(1, 1, NULL, '2026-06-24 09:39:00', 750.0, 'Wire Transfer', 1, 'WT-67'),
(2, 3, NULL, '2026-07-20 16:37:00', 520.0, 'Check', 1, 'CHK-104511'),
(3, 6, NULL, '2026-07-31 13:18:00', 80.0, 'Wire Transfer', 1, 'WT-88'),
(4, 5, NULL, '2026-08-28 15:22:00', 120.0, 'Credit Card', 1, 'CC-88210051'),
(5, NULL, 1, '2026-09-07 10:38:00', 644.76, 'Credit Card', 0, 'CC-88210063'),
(6, NULL, 2, '2026-09-13 10:17:00', 325.08, 'Credit Card', 0, 'CC-88210077'),
(7, NULL, 3, '2026-09-27 11:06:00', 151.2, 'Credit Card', 0, 'CC-88210108'),
(8, 8, NULL, '2026-10-02 11:40:00', 680.0, 'Check', 1, 'CHK-104558'),
(9, NULL, 4, '2026-10-08 11:39:00', 927.18, 'Credit Card', 0, 'CC-88210112'),
(10, NULL, 9, '2026-10-22 12:18:00', 2881.44, 'Wire Transfer', 0, 'WT-113'),
(11, NULL, 12, '2026-10-29 16:15:00', 579.96, 'Wire Transfer', 0, 'WT-227'),
(12, NULL, 5, '2026-11-06 10:13:00', 773.28, 'Cash', 0, 'CSH-1037'),
(13, NULL, 6, '2026-11-06 11:15:00', 71.28, 'Credit Card', 0, 'CC-88210205'),
(14, NULL, 11, '2026-11-14 09:01:00', 270.0, 'Wire Transfer', 0, 'WT-140'),
(15, NULL, 7, '2026-11-15 09:44:00', 451.44, 'Credit Card', 0, 'CC-88210241'),
(16, NULL, 8, '2026-11-15 09:46:00', 451.44, 'Credit Card', 0, 'CC-88210324'),
(17, NULL, 14, '2026-09-04 10:05:00', 644.76, 'Credit Card', 0, 'CC-STAY-11'),
(18, NULL, 15, '2026-09-10 10:05:00', 494.64, 'Credit Card', 0, 'CC-STAY-12'),
(19, NULL, 16, '2026-09-20 10:05:00', 1130.76, 'Credit Card', 0, 'CC-STAY-13'),
(20, NULL, 17, '2026-09-30 10:05:00', 429.84, 'Credit Card', 0, 'CC-STAY-14'),
(21, NULL, 18, '2026-10-12 10:05:00', 774.36, 'Credit Card', 0, 'CC-STAY-15'),
(22, NULL, 19, '2026-10-15 10:05:00', 840.24, 'Credit Card', 0, 'CC-STAY-16'),
(23, NULL, 20, '2026-10-23 10:05:00', 1507.68, 'Credit Card', 0, 'CC-STAY-17'),
(24, NULL, 21, '2026-10-31 10:05:00', 644.76, 'Credit Card', 0, 'CC-STAY-18'),
(25, NULL, 22, '2026-11-09 10:05:00', 494.64, 'Credit Card', 0, 'CC-STAY-19'),
(26, NULL, 23, '2026-11-18 10:05:00', 753.84, 'Credit Card', 0, 'CC-STAY-20');

INSERT INTO AllocationEntry (allocationID, chargeID, unbilledAccountID, invoiceID, splitPercent) VALUES
(1, 1, NULL, 9, 100.0),
(2, 2, NULL, 9, 100.0),
(3, 3, NULL, 9, 100.0),
(4, 4, NULL, 10, 100.0),
(5, 5, NULL, 10, 100.0),
(6, 6, NULL, 10, 100.0),
(7, 7, NULL, 11, 100.0),
(8, 8, 6, NULL, 100.0),
(9, 9, 6, NULL, 100.0),
(10, 10, NULL, 6, 100.0),
(11, 11, NULL, 6, 100.0),
(12, 12, NULL, 1, 100.0),
(13, 13, NULL, 2, 100.0),
(14, 14, NULL, 2, 100.0),
(15, 15, NULL, 12, 100.0),
(16, 16, NULL, 3, 100.0),
(17, 17, NULL, 4, 100.0),
(18, 18, NULL, 4, 100.0),
(19, 19, NULL, 13, 100.0),
(20, 20, NULL, 5, 100.0),
(21, 21, NULL, 7, 50.0),
(22, 21, NULL, 8, 50.0),
(23, 22, NULL, 14, 100.0),
(24, 23, NULL, 15, 100.0),
(25, 24, NULL, 16, 100.0),
(26, 25, NULL, 17, 100.0),
(27, 26, NULL, 18, 100.0),
(28, 27, NULL, 19, 100.0),
(29, 28, NULL, 20, 100.0),
(30, 29, NULL, 21, 100.0),
(31, 30, NULL, 22, 100.0),
(32, 31, NULL, 23, 100.0);

COMMIT;
